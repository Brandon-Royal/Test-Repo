﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml;
using Sitecore.Poc.DataService.Models;

namespace Sitecore.Poc.DataService.Repositories
{
    public class PeopleRepository : IEntityRepository
    {
        public IEnumerable<Person> GetAll()
        {
            var path = GetPath();
            if (!string.IsNullOrEmpty(path) && FileExists(path))
            {
                var list = new List<Person>();
                var xmlDocument = new XmlDocument();
                xmlDocument.Load(path);
                var nodes = xmlDocument.SelectNodes("people/*");
                if (nodes == null || nodes.Count == 0) return Enumerable.Empty<Person>();
                foreach (XmlNode node in nodes)
                {
                    if (!node.HasChildNodes) continue;
                    var person = GetPerson(node);
                    list.Add(person);
                }
                return list;
            }
            return null;
        }

        

        public Person GetSingle(string id)
        {
            var email = id;
            var path = GetPath();
            if (!string.IsNullOrEmpty(path) && FileExists(path))
            {
                var xmlDocument = new XmlDocument();
                xmlDocument.Load(path);
                var query = string.Format("people/person[email='{0}']", email);
                var node = xmlDocument.SelectSingleNode(query);
                if (node != null && node.HasChildNodes)
                {
                    return GetPerson(node);
                }
            }
            return null;
        }

        public void AddSingle(string id)
        {

        }

        public void UpdateSingle(string id, object entity)
        {
            var email = id;
            var person = entity as Person;
            var path = GetPath();
            if (!string.IsNullOrEmpty(path) && FileExists(path))
            {
                var xmlDocument = new XmlDocument();
                xmlDocument.Load(path);
                var query = string.Format("people/person[email='{0}']", email);
                var node = xmlDocument.SelectSingleNode(query);
                if (node != null && node.HasChildNodes)
                {
                    UpdatePerson(node, person);
                }
                xmlDocument.Save(path);
            }
        }

        public void DeleteSingle(string id)
        {

        }

        private static string GetPath()
        {
            var appPath = HttpContext.Current.Request.PhysicalApplicationPath;
            if (string.IsNullOrEmpty(appPath)) return string.Empty;
            var appdataPath = Path.Combine(appPath, "App_Data");
            return Path.Combine(appdataPath, "people.xml");
        }

        private static bool FileExists(string path)
        {
            return File.Exists(path);
        }

        private static Person GetPerson(XmlNode node)
        {
            var person = new Person();
            foreach (XmlNode innerNode in node.ChildNodes)
            {
                switch (innerNode.Name)
                {
                    case "firstName":
                        person.FirstName = innerNode.InnerText;
                        break;
                    case "lastName":
                        person.LastName = innerNode.InnerText;
                        break;
                    case "email":
                        person.Email = innerNode.InnerText;
                        break;
                    case "description":
                        person.Description = innerNode.InnerText;
                        break;
                    case "jobTitle":
                        person.JobTitle = innerNode.InnerText;
                        break;
                }
            }
            return person;
        }

        private static void UpdatePerson(XmlNode node, Person person)
        {
            for (int i = 0; i < node.ChildNodes.Count; i++)
            {
                switch (node.ChildNodes[i].Name)
                {
                    case "firstName":
                        node.ChildNodes[i].InnerText = person.FirstName ?? "";
                        break;
                    case "lastName":
                        node.ChildNodes[i].InnerText = person.LastName ?? "";
                        break;
                    case "email":
                        node.ChildNodes[i].InnerText = person.Email ?? "";
                        break;
                }
            }
        }
    }
}