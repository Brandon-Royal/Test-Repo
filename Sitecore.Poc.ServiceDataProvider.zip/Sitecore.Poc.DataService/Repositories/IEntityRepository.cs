﻿using System.Collections.Generic;
using Sitecore.Poc.DataService.Models;

namespace Sitecore.Poc.DataService.Repositories
{
    public interface IEntityRepository
    {
        IEnumerable<Person> GetAll();

        Person GetSingle(string id);

        void AddSingle(string id);

        void UpdateSingle(string id, object entity);

        void DeleteSingle(string id);
    }
}