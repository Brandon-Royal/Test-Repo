﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Sitecore.Poc.DataService.Models;
using Sitecore.Poc.DataService.Repositories;

namespace Sitecore.Poc.DataService.Controllers
{
    public class PeopleController : ApiController
    {
        IEntityRepository _repository;

        public PeopleController(IEntityRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Gets all people
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Person> Get()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets a single person by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Person Get(string id)
        {
            var email = HttpUtility.UrlDecode(id);
            return _repository.GetSingle(email);
        }

        /// <summary>
        /// Updates a person by id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="person"></param>
        public void Put(string id, [FromBody] Person person)
        {
            _repository.UpdateSingle(id, person);
        }
    }
}
